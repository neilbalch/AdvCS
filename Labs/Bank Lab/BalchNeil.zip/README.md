# Neil Balch's Bank Lab

## Challenge: Automatic logout timeout timer.