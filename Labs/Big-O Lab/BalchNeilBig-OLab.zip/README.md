# Big-O Lab

## Challenge: extra scrambling and sorting options.