# Inheritance Lab

## Challenge Selected: 1: option to delete employees.
