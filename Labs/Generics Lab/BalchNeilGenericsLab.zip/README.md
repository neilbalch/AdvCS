# Generics Lab

## Challenge: Functionality to delete a period/class from a schedule.