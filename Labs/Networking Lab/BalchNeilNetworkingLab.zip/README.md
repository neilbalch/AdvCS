# Neil's Networking Lab

## Challenge: Animations for win/lose/tie.