# Neil Balch's Maps Lab

## Chalenge: the one where we have student schedules.