# Sets Lab

## Challenge: add and remove an item to and from the HashSet and TreeSet, updating the `JScrollPane`s. 