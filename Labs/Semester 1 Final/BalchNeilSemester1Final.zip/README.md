# Neil Balch's Semester 1 Final Project

## Challenge: 2 each of 3 types of impassible areas.